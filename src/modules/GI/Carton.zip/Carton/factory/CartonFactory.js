(function() {
    'use strict';
    app.factory("cartonFactory",
        function($q, $http, ngAuthSettings, localStorageService, webServiceAPI, clientService) {

        return {
            get: clientService.get,
            post: clientService.post,
            url: webServiceAPI.OmniWms + "PutToStore",
            getDefaultOwner: function(userId) {
                var urlRequest = this.url + "/GetDefaultOwner";
                return clientService.post(urlRequest, { UserId: userId });
            },
            getCartonStatus: function (body) {
                // var urlRequest = this.url + "/GetCartonStatus"
                var urlRequest = "http://10.0.177.30/UAT_CFM_NewFW_GIAPI/api/loadToTruck/GetCartonStatus"
                return clientService.post(urlRequest, body)
            },
            getTruckRoute: function(body) {
                // var urlRequest = this.url + "/GetTruckRoute"
                var urlRequest = "http://10.0.177.30/UAT_CFM_NewFW_GIAPI/api/loadToTruck/GetTruckRoute"
                return clientService.post(urlRequest, body);
            },
            getStoreByRoute: function (body) {
                // var urlRequest = this.url + "/GetStoreByRoute"
                var urlRequest = "http://10.0.177.30/UAT_CFM_NewFW_GIAPI/api/loadToTruck/GetStoreByRoute"
                return clientService.post(urlRequest, body)
            },
            getCartonStore: function(body){
                // var urlRequest = this.url + "/GetCartonStore"
                var urlRequest = "http://10.0.177.30/UAT_CFM_NewFW_GIAPI/api/loadToTruck/GetCartonStore"
                return clientService.post(urlRequest, body)
            },
            updateCartonStatus: function(body){
                var urlRequest = "http://10.0.177.30/UAT_CFM_NewFW_GIAPI/api/loadToTruck/UpdateCartonStatus"
                return clientService.post(urlRequest, body)
            }
        }
    });
})();