(function() {
    'use strict';
    app.component('cartonFilter', {
        controllerAs: '$vm',
        templateUrl: function($element, $attrs, /*ngAuthSettings,*/ $window, commonService) {
            return "modules/GI/Carton/component/CartonFilter.html";
        },
        bindings: {
            filterModel: '=?',
            triggerSearch: '=?',
            triggerCreate: '=?',
            searchResultModel: '=?',
            saleOrderTable: '=?',
            saleOrderTableRender: '=?'
        },
        controller: function($scope, $q, cartonFactory, localStorageService, planGoodsIssueFactory, pageLoading, dpMessageBox) {
           
            var $vm = this;
            
            $scope.truckRouteSelected = [];
            $scope.storeSelected = [];
            $scope.truckRouteData = [];
            $scope.storeData = [];
            $scope.truckIdList = [];
            $scope.truckRouteSetting = { showCheckAll: false, showUncheckAll: false, checkBoxes: true, displayProp: 'truckRoundName', idProp: 'truckRoundId' };
            $scope.storeSetting = { showCheckAll: false, showUncheckAll: false, checkBoxes: true, displayProp: 'storeName', idProp: 'storeNo' };
            $scope.isFilter = true;
            $scope.storeList = [];

            $scope.filterModel = {
                currentPage: 0,
                perPage: 15,
                totalRow: 0,
                key: '',
                advanceSearch: false,
                showError: false,
                type: 1,
                chkinitpage: false,
                maxSize: 10,
                num: 1,
            };

            $scope.pageOption = [
                { value: 15 },
                { value: 30 },
                { value: "All" },
            ];

            $scope.changePage = function() {
                var page = $vm.filterModel;

                var all = {
                    currentPage: 0,
                    perPage: 0
                };
                if ($vm.filterModel.currentPage != 0) {
                    page.currentPage = page.currentPage;
                }

                $scope.filterSearch();
            }

            $scope.changeTableSize = function() {
                console.log($vm.filterModel.perPage);
                var p = {
                    currentPage: 0, //$scope.pagging.num,
                    perPage: $vm.filterModel.perPage
                };
                $vm.filterModel.perPage = $vm.filterModel.perPage;
                $scope.filterSearch();
            };

            $scope.searchFilter = function(param) {
                const req = {
                    columnName: param.columnName,
                    currentPage: param.currentPage,
                    numPerPage: param.numPerPage,
                    orderBy: param.orderBy,
                    perPage: param.perPage,
                    planGoodsIssueDueDate: param.planGoodsIssueDueDate,
                    planGoodsIssueDueDateTo: param.planGoodsIssueDueDateTo,
                    totalRow: param.totalRow,

                }
                var deferred = $q.defer();
                planGoodsIssueFactory.planGIsearch(req).then(
                    function success(res) {
                        console.log(res);
                        deferred.resolve(res);
                    },
                    function error(response) {
                        deferred.reject(response);
                    });
                return deferred.promise;
            }

            $scope.serchPage = function() {
                console.log('change page');
                runWaveFactory.runWavesearch(param).then(function success(res) {

                    $vm.filterModel.totalRow = res.data.pagination.totalRow;
                    $vm.filterModel.currentPage = res.data.pagination.currentPage;
                    $vm.filterModel.perPage = res.data.pagination.perPage;
                    $vm.filterModel.numPerPage = res.data.pagination.perPage;
                    $vm.searchResultModel = res.data.items;
                }, function error(res) {});
            };

            $scope.popupOwner = {
                onShow: false,
                delegates: {},
                onClick: function(param, index) {
                    console.log(param);
                    $scope.popupOwner.onShow = !$scope.popupOwner.onShow;
                    $scope.popupOwner.delegates.ownerPopup(param, index);
                },
                config: {
                    title: "owner"
                },
                invokes: {
                    add: function(param) {},
                    edit: function(param) {},
                    selected: function(param) {
                        $scope.filterModel.ownerIndex = angular.copy(param.ownerIndex);
                        $scope.filterModel.ownerId = angular.copy(param.ownerId);
                        $scope.filterModel.ownerName = angular.copy(param.ownerName);
                        $scope.filterModel.ownerNameTemp = $scope.filterModel.ownerName;
                        document.getElementById("owner_id_input_show").focus();
                    }
                }
            };

            $scope.loadDefaultOwner = function() {
                cartonFactory.getDefaultOwner(localStorageService.get('userTokenStorage')).then(
                    function success(res) {
                        console.log(res.data.result);
                        $scope.filterModel.ownerId = res.data.result[0].ownerID;
                        $scope.filterModel.ownerIndex = res.data.result[0].ownerIndex;
                        $scope.filterModel.ownerName = res.data.result[0].ownerName;
                        $scope.filterModel.ownerNameTemp = res.data.result[0].ownerName;
                    },
                    function error(err) {
                        $scope.filterModel.ownerId = "";
                        $scope.filterModel.ownerIndex = "";
                        $scope.filterModel.ownerName = "";
                        $scope.filterModel.ownerNameTemp = "";
                    });
            }

            $scope.loadTruckRoute = function() 
            {
                let body = { userId : localStorageService.get('userTokenStorage')};
                cartonFactory.getTruckRoute(body).then(
                    function success(res) {
                        if(res.data.statusCode == 200){
                            $scope.truckRouteData = res.data.result;
                    }
                },
                function error(err) {
                    console.log("err",err);
                });
                pageLoading.hide();
            }

            $scope.changeTruckRoute = {
                onSelectionChanged: function() {
                    // filter store
                    console.log('filter store');
                    if($scope.truckRouteSelected.length == 0)
                    {
                        $scope.storeData = [];
                    }
                    else
                    {   
                        $scope.truckIdList = [];
                        $scope.truckRouteSelected.forEach((value, index) => {
                            $scope.truckIdList.push(value.truckRoundId)
                            pageLoading.hide();
                        });
                        
                        
                        let body = { TruckRouteIds: $scope.truckIdList, UserId: localStorageService.get('userTokenStorage') }
                        cartonFactory.getStoreByRoute(body)
                        .then(function success(res){
                            console.log(res);
                            if(res.data.statusCode === "200"){
                                $scope.storeData = res.data.result;
                                
                            }
                            pageLoading.hide();
                        },
                        function error(err) {
                        });
                    }  
                     
                },
            }

            $scope.loadStatusCarton = function() {
                let body = { TruckRouteIds: $scope.truckRouteIds, StoreNos: $scope.storeList, UserId: localStorageService.get('userTokenStorage')};
                cartonFactory.getCartonStatus(body).then(function success(res)
                {
                     if(res.data.statusCode == "200"){
                        $scope.filterModel.cartonStatusName = res.data.result[0].statusName;
                        $scope.filterModel.cartonStatus = res.data.result[0].statusId;
                     }
                     pageLoading.hide();
                },
                function error(err){});
            }

            $scope.filterSearch = function() {
                let body = {
                    Size: $vm.filterModel.perPage == "All" ? null : $vm.filterModel.perPage,
                    Page: $vm.filterModel.currentPage,
                    RequestBody: {
                        CartonStatusId: $scope.filterModel.cartonStatus, //number
                        StoreNos: $scope.storeList, 
                        UserId: localStorageService.get('userTokenStorage')
                    }
                }

                cartonFactory.getCartonStore(body).then(function success(param) {
                    if(param.data.statusCode == "200"){
                        console.log(param);
                        $scope.filterModel.totalRow = param.data.totalRow;
                        $scope.filterModel.currentPage = $vm.filterModel.currentPage;
                        $scope.filterModel.perPage = $vm.filterModel.perPage;
                        $scope.filterModel.numPerPage = $vm.filterModel.numPerPage;

                        $vm.searchResultModel = param.data.result;
                        pageLoading.hide();
                    }
                })
            }

            $scope.changeStoreRoute = {
                onSelectionChanged: function() {
                    // filter store
                    console.log('filter store');
                    if($scope.storeSelected.length == 0)
                    {
                        $scope.storeData = [];
                    }
                    else
                    {   
                        $scope.storeList = [];
                        $scope.storeSelected.forEach((value, index) => {
                            $scope.storeList.push(value.storeNo)
                        });

                        pageLoading.hide();
                        $scope.loadStatusCarton();
                    }  
                },
            }


            $scope.detectCheckAll = function() {
                if ($scope.checkAll === true) {
                    angular.forEach($vm.searchResultModel, function(v, k) {
                        $vm.searchResultModel[k].selected = true;
                    });
                } else {
                    angular.forEach($vm.searchResultModel, function(v, k) {
                        $vm.searchResultModel[k].selected = false;
                    });
                }
            }

            $scope.clear = function() {
                $scope.loadDefaultOwner();
                $scope.filterModel = {};
                $scope.truckRouteSelected = [];
                $scope.storeSelected = [];
                $scope.storeData = [];
                $vm.searchResultModel = [];
                console.log('clear');

            }

            $scope.confirmCloseCarton = function(){
                let cartonNos = $vm.searchResultModel.filter(it => it.selected == true).map(i => i.cartonNo);
                let body = {
                    userId: localStorageService.get('userTokenStorage'),
                    cartonStatusId: $scope.filterModel.cartonStatus,
                    cartonNos: cartonNos
                  }

               cartonFactory.updateCartonStatus(body).then(function success(res){
                   pageLoading.hide();
                   if(res.data.statusCode == "200"){
                        $scope.clear();
                        dpMessageBox.alert({
                            ok: 'Yes',
                            title: 'Success',
                            message: res.data.statusDesc
                       }); 
                   }else{
                        dpMessageBox.alert({
                            ok: 'Yes',
                            title: 'Error',
                            message: res.data.statusDesc
                        }); 
                   }
                   pageLoading.hide();

               })
            }

            this.$onInit = function() {
                // $scope.filterModel = {};
                $scope.filterModel.ownerId = "";
                $scope.filterModel.ownerIndex = "";
                $scope.filterModel.ownerName = "";
                $scope.filterModel.ownerNameTemp = "";

                $scope.loadDefaultOwner();
                $scope.loadTruckRoute();
                pageLoading.hide();
            };
        }
    });
})();